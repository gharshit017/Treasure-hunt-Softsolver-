function openLogoutDialog() {
	document.getElementById("logout-dialog").style.display = "flex";
}



function confirmLogout() {
	window.location.href = "login.html";
}

